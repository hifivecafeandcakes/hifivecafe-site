const BASEURL = `${process.env.REACT_APP_FRONT_URL}`

export default BASEURL