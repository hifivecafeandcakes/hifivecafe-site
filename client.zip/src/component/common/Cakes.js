export const cakes = [
    {value:"1",label:"Red velvet cake"},
    {value:"2",label:"Carrot cake"},
    {value:"3",label:"Chocolate cake"},
    {value:"4",label:"Cheesecake"},
    {value:"5",label:"Pound cake"},
    {value:"6",label:"Angel food cake"},
    {value:"7",label:"Sponge cake"},
    {value:"8",label:"Black Forest cake"},
    {value:"9",label:"Chiffon cake"},
    {value:"10",label:"Flourless Cake (baked & unbaked)"}
]