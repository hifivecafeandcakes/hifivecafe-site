import React, { useEffect, useState } from 'react'
import "bootstrap/dist/css/bootstrap.min.css"
import Navbar from "../Navbar";
import TextField from '@mui/material/TextField';
import '../../theme/css-component/CLT_cart.css'
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import axios from 'axios';
import InstagramIcon from '@mui/icons-material/Instagram';
import FacebookIcon from '@mui/icons-material/Facebook';
import XIcon from '@mui/icons-material/X';
import { IconButton } from '@mui/material';
import MenuSlider from './MenuSlider';
import Status from './Status';
import { useNavigate } from "react-router-dom";
import CustomSlider from './CustomSlider';
import CustomSubSlider from './CustomSubSlider';




const CltCart = () => {
    const user_id = localStorage.getItem("user_id")
    const res_id = localStorage.getItem('res_id');
    const res_cat_id = localStorage.getItem('res_cat_id');
    const res_scat_id = localStorage.getItem('res_scat_id');

    const navigate = useNavigate();

    useEffect(() => {
        if (!user_id) {
            window.location.href = '/logIn';
        } else {
            fetchData();
        }
    }, []);

    //fetching parameters
    const [subcatres, setSubcatres] = useState(''); //actual fetching subcat data
    const [menuImages, setMenuImages] = useState([]); //actual data

    // form parameter
    const [date, setDate] = useState('');
    const [time, setTime] = useState('');
    const [guestName, setGuestName] = useState('');
    const [numOfPeople, setNumOfPeople] = useState(1);
    const [vegOrNon, setVegOrNon] = useState('1');
    const [menu, setMenu] = useState(1);
    const [cake, setCake] = useState('');
    const [cakeMsg, setCakeMsg] = useState('');
    const [comment, setComment] = useState('');


    //Error
    const [dateError, setDateError] = useState(false);
    const [timeError, setTimeError] = useState(false);
    const [guestNameError, setGuestNameError] = useState(false);

    // status
    const empStatus = { msg: "", type: "success", toggle: "close" }
    const [status, setStatus] = useState(empStatus);


    // Slick
    const [refreshKey, setRefreshKey] = useState(0);
    const [slicksetting, setSlicksetting] = useState("");

    // useEffect(() => {

    //     setMenuImages(menuImages);
    // }, [menuImages]);


    const fetchData = async () => {
        try {
            const res = await axios.get(`${process.env.REACT_APP_API_URL}/candle/light/dinner/res/subcat?res_id=${res_id}&res_cat_id=${res_cat_id}&reser_sub_id=${res_scat_id}`)
            if (res.data.Response.Success == 1) {
                let reservation_subcategory = res.data.Response.result.reservation_subcategory;
                if (reservation_subcategory.length > 0) {
                    setSubcatres(reservation_subcategory[0]);
                    console.log("RES :", res.data.Response.result.reservation_subcategory[0]);
                    if (reservation_subcategory[0].sub_extra_img.length > 0) {

                        var arr_img = reservation_subcategory[0].sub_extra_img;
                        arr_img.unshift(reservation_subcategory[0].sub_img);
                        console.log(arr_img);

                        // setMenuImages([reservation_subcategory[0].sub_img, ...reservation_subcategory[0].sub_extra_img]);
                        setMenuImages([...arr_img]);
                        setRefreshKey(prevKey => prevKey + 1);
                    }
                }
                else {
                    console.log("No data found.");
                }
            }
            else {
                console.log("No data found.");
            }
        } catch (err) {
            console.error("Error fetching data:", err);
        }
    };

    // const settings = {
    //     dots: true,
    //     infinite: true,
    //     speed: 500,
    //     slidesToShow: 1,
    //     slidesToScroll: 1,
    // };


    const handleSubmit = async (e) => {
        e.preventDefault();
        console.log('userid', user_id);

        (date == "") ? setDateError(true) : setDateError(false);
        (time == "") ? setTimeError(true) : setTimeError(false);
        (guestName == "") ? setGuestNameError(true) : setGuestNameError(false);

        console.log('guestNameError', guestNameError);
        console.log('dateError', dateError);
        console.log('timeError', timeError);

        if (guestNameError || dateError || timeError) {
            setStatus({ msg: "Please fill all required (*) fields", type: "error", toggle: "open" })
            return;
        }

        const formData = new FormData();
        formData.append('userid', user_id);
        formData.append('reser_id', res_id);
        formData.append('reser_catid', res_cat_id);
        formData.append('resersubcatid', res_scat_id);
        formData.append('type', "CL");

        formData.append("date", date);
        formData.append("time", time);
        formData.append("peoples", numOfPeople);
        formData.append("menu_type", menu);
        formData.append("veg_or_nonveg", vegOrNon);
        formData.append("guest_name", guestName);
        formData.append("cake", cake);
        formData.append("cake_msg", cakeMsg);
        formData.append("remarks", comment);

        try {
            const res = await axios.post(`${process.env.REACT_APP_API_URL}/reservation/booking/create`, formData)
            console.log("RESPONSE :", res.data);
            if (res?.data?.Response?.Success == '1') {
                let results = res?.data?.Response?.RazorpayOrder;
                results.booking_id = res?.data?.Response?.ReservationId;
                results.user = res?.data?.Response?.user[0];
                results.reservationSubCategory = res?.data?.Response?.reservationSubCategory[0];
                setStatus({ msg: "Booked Successfully!", type: "success", toggle: "open" });
                navigate('/checkout', { state: results });
                // window.location.href = '/reservation';
            } else if (res.data.message == 'Give Valid Id') {
                setStatus({ msg: "Give Valid Id", type: "error", toggle: "open" })
                console.log('Give Valid Id');
            } else {
                setStatus({ msg: "Error in Booking. Try Again", type: "error", toggle: "open" })
                console.log('Execution Error');
            }
        } catch (err) {
            setStatus({ msg: "Error in Booking. Try Again", type: "error", toggle: "open" })
            console.log('Fetching Error:', err);
        }
    }

    // function sliders() {
    //     return menuImages.map((item, i) => {
    //         return (
    //             <div key={i + 1}>
    //                 <img src={item}
    //                     alt="img"
    //                     style={{ width: '100%', height: "60vh", borderRadius: '10%' }} />
    //             </div>)
    //     })
    // }

    return (
        <>
            <div className='container-fluid '>
                <div className='row' style={{ backgroundColor: 'rgba(0, 0, 0, 0.6)' }}>
                    <div className='col-lg-12'>
                        <div className='row'>
                            <Navbar />
                        </div>
                        <div className='row CLT_cart_row1'>

                        </div>
                        <div className='row'>
                            <div className='col-lg-12 mt-4'>
                                <h1 className='text-center'
                                    style={{ color: 'orange', fontFamily: '"Bebas Neue", sans-serif' }}>
                                    {subcatres.reser_main_title}</h1>
                            </div>

                            <div className='col-lg-12'>
                                <h4 className='text-center'
                                    style={{ color: 'orange', fontFamily: '"Bebas Neue", sans-serif' }}>
                                    {subcatres.cat_title}</h4>
                            </div>
                        </div>
                        <div className='row BTB_cart_row12'>
                            <div className='col-lg-12 p-5'>
                                <h2>
                                    {subcatres.description}
                                </h2>
                            </div>
                        </div>

                        <div className='row CLT_cart_row2'>

                            <div className='col-lg-4 CLT_cart_row2_1 customsubslide'>
                                {/* <img style={{ border: '1px solid orange', borderRadius: '10%' }}
                                    src={subcatres.sub_img} alt="res sub cat image" /> */}


                                {(refreshKey != 0 && menuImages.length > 0) ?
                                    // <MenuSlider menuImages={menuImages} />
                                    <CustomSubSlider images={menuImages} />
                                    : ""}
                                <h2>CODE : {subcatres.sub_tilte}</h2>
                                <h2>&#8377;&nbsp;{subcatres.sub_cat_price_range}</h2>
                            </div>
                            <div className="col-lg-4 CLT_cart_row2_2 ">
                                <div className='CLT_cart_row2_2_div'>
                                    <Status msg={status.msg} type={status.type} toggle={status.toggle} onClose={() => setStatus(empStatus)} />
                                    <div className="row p-2">
                                        <div className='col-lg-6'>
                                            <label className='required'>Date</label>
                                            <input type="date" className="required form-control p-2" onChange={(e) => { setDateError(false); setDate(e.target.value) }} />
                                            {(dateError) ? <span className='error'>This is field required</span> : ""}
                                        </div>
                                        <div className='col-lg-6'>
                                            <label className='required'>Time</label>
                                            <input type="time" className="form-control p-2" onChange={(e) => { setTimeError(false); setTime(e.target.value) }} />
                                            {(timeError) ? <span className='error'>This is field required</span> : ""}
                                        </div>
                                    </div>

                                    <div className='p-2'>
                                        <label className='required'>Guest Name</label>
                                        <input type="text" className="form-control p-2" required onChange={(e) => { setGuestNameError(false); setGuestName(e.target.value); }} />
                                        {(guestNameError) ? <span className='error'>This is field required</span> : ""}
                                    </div>

                                    <div className="row p-2">

                                        <div className='col-md-6'>
                                            <label className='required'>No. of People</label>
                                            <select className="form-control p-2" onChange={(e) => setNumOfPeople(e.target.value)}>
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                            </select>
                                        </div>

                                        <div className='col-md-6'>
                                            <label className='required'>Veg or non-veg</label>
                                            <select className="form-control p-2" onChange={(e) => setVegOrNon(e.target.value)}>
                                                <option value="1">Veg</option>
                                                <option value="2">Non-veg</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div className="row p-2">

                                        <div className='col-md-6'>
                                            <label className='required'>Select Menu</label>
                                            <select className="form-control p-2" onChange={(e) => { setMenu(e.target.value) }}>
                                                <option value="1">Menu-1</option>
                                                <option value="2">Menu-2</option>
                                                <option value="3">Menu-3</option>
                                                <option value="4">Menu-4</option>
                                                <option value="5">Menu-5</option>
                                                <option value="6">Menu-6</option>
                                                <option value="7">Menu-7</option>
                                                <option value="8">Menu-8</option>
                                                <option value="9">Menu-9</option>
                                                <option value="10">Menu-10</option>
                                            </select>
                                        </div>


                                        <div className='col-md-6'>
                                            <label>Choose Cake</label>
                                            <select className="form-control p-2" onChange={(e) => setCake(e.target.value)}>
                                                <option value="">None</option>
                                                <option value="1">Cake-1</option>
                                                <option value="2">Cake-2</option>
                                                <option value="3">Cake-3</option>
                                                <option value="4">Cake-4</option>
                                            </select>
                                        </div>
                                    </div>


                                    <div className='p-2'>
                                        <label>Cake Message</label>
                                        <input type="text" className="form-control p-2" onChange={(e) => setCakeMsg(e.target.value)} />
                                    </div>

                                    <div className='p-2'>
                                        <label>Additional Comments</label>
                                        <input type="text" className="form-control p-2" onChange={(e) => setComment(e.target.value)} />
                                    </div>

                                    <div className='p-2' style={{ width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                                        <button type='button' className='btn home_action2_btn' onClick={handleSubmit} >Book NOW</button>
                                    </div>
                                </div>
                            </div>


                            {/* =================================== */}

                            <div className='col-lg-4 CLT_cart_row2_3 customslide'>
                                {(refreshKey != 0 && menuImages.length > 0) ?
                                    // <MenuSlider menuImages={menuImages} />
                                    <CustomSlider images={menuImages} />
                                    : ""}

                            </div>

                        </div>
                        {/* ===================================================================================== */}
                        <div className='row  home_col3_3'>
                            <div className='col-lg-4  home_col3_1 ' style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', backgroundColor: '#ffeeda' }}>
                                <div style={{ textAlign: 'center' }}>
                                    <h1 >Wedding Event Hall</h1>
                                    <h1 >Candle Light Dinner</h1>
                                    <h1>Book Team Lunch</h1>
                                    <h1>Quick Cake Delivery</h1>
                                    <h1>Birthday Cakes</h1>
                                </div>
                            </div>
                            <div className='col-lg-4  home_col1_3 ' style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', backgroundColor: '#ffeeda' }}>
                                <div style={{ textAlign: 'center' }}>
                                    <p>Find Us</p>
                                    <h1 >Hifive Cafe and Cakes, 3, Sathy Rd,
                                        Ramanandha Nagar, Saravanampatti, Coimbatore</h1>
                                    <h1>+91 99408 88633,<br /> contact@hifivecafe.com</h1>
                                    <h1>Open: 11:00 am – 10:00 pm</h1>
                                    <div>
                                        <IconButton style={{ color: 'orange' }}>
                                            <InstagramIcon />
                                        </IconButton>

                                        <IconButton style={{ color: 'orange' }}>
                                            <FacebookIcon />
                                        </IconButton><IconButton style={{ color: 'orange' }}>
                                            <XIcon />
                                        </IconButton>

                                    </div>

                                </div>


                            </div>
                            <div className='col-lg-4  home_col3_1 ' style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', backgroundColor: '#ffeeda' }}>
                                <div style={{ textAlign: 'center' }}>
                                    <h1 >Privacy Policy</h1>
                                    <h1 >Terms & Conditions</h1>
                                    <h1>Refund Policy</h1>
                                    <h1>Shipping Policy</h1>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </>
    )
}

export default CltCart
